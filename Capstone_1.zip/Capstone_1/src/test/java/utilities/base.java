package utilities;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.*;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.commons.io.FileUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

public class base {

	    public static WebDriver driver;
	    public static Properties prop;
	    public static Logger log = Logger.getLogger(base.class);
	    public base() {
	    	PropertyConfigurator.configure("src\\test\\resources\\log4j.properties");
	        log.info("Log4j initialized successfully");
	    }
	   
	   
	    public void loadConfig() {
	        try {
	            prop = new Properties();
	            FileInputStream fis = new FileInputStream("src/test/resources/config.properties");
	            prop.load(fis);
	            log.info("Config file loaded successfully");
	        } catch (IOException e) {
	            log.error("Failed to load config file: " + e.getMessage());
	        }
	    }

	    public void launch_chrome() {
	        try {
	            System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
	            driver = new ChromeDriver();
	            driver.manage().window().maximize();
	            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(0));
	            loadConfig();
	            // Read URL from config.properties
	            String url = prop.getProperty("url");
	            driver.get(url);
//2025-11-14 11:21:49 ERROR base:50 - Failed to launch Chrome: Cannot invoke "java.util.Properties.getProperty(String)" 
	            //because "utilities.base.prop" is null
	            log.info("Chrome launched successfully.");
	        } catch (Exception e) {
	            log.error("Failed to launch Chrome: " + e.getMessage());
	        }
	    }

	    public void launchEdge() {
	        try {
	            System.setProperty("webdriver.edge.driver", "edgedriver_v141.exe");
	            driver = new EdgeDriver();
	            driver.manage().window().maximize();
	            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(0));

	            // Read URL from config.properties
	            String url = prop.getProperty("url");
	            driver.get(url);

	            log.info("Edge launched successfully.");
	        } catch (Exception e) {
	            log.error("Failed to launch Edge: " + e.getMessage());
	        }
	    }
	

    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
            log.info("Browser closed.");
        }
    }

    
    public WebDriverWait getWait(long seconds) {
        return new WebDriverWait(driver, Duration.ofSeconds(seconds));
    }

   
    public void waitForOverlaysToDisappear() {
        By overlay = By.cssSelector(".loading, .ajax-loader, .overlay, .spinner, .please-wait, .ajax-loading-block-window");
        try {
            if (!driver.findElements(overlay).isEmpty()) {
                getWait(10).until(ExpectedConditions.invisibilityOfElementLocated(overlay));
                log.info("Overlays/spinners disappeared.");
            }
        } catch (TimeoutException te) {
            log.warn("Overlay did not disappear within timeout. Proceeding anyway.");
        } catch (Exception e) {
            log.warn("Overlay wait skipped due to exception: " + e.getMessage());
        }
    }

    
    public void javaScriptClick(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", element);
        log.info("Clicked element using JavaScript.");
    }

    public void scrollIntoView(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", element);
        log.info("Scrolled into view: " + element);
    }

    //Alert
    public void handleAlertIfPresent() {
        try {
            Alert alert = driver.switchTo().alert();
            alert.accept();
            log.info("Alert accepted.");
        } catch (NoAlertPresentException e) {
            log.warn("No alert present.");
        }
    }

    // Explicit Wait
    public void explicitWait(String xpath, String conditionType) {
        log.info("Explicit wait for XPath: " + xpath + " | condition: " + conditionType);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        switch (conditionType.toLowerCase()) {
            case "presence":
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
                break;
            case "visibility":
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
                break;
            case "clickable":
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
                break;
            default:
                log.warn("Invalid condition type provided: " + conditionType);
        }

        log.info("Explicit wait completed for condition: " + conditionType);
    }

    //Fluent Wait
    public void fluentWait(WebElement element) {
        log.info("Fluent wait for element: " + element);
        Wait<WebDriver> wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(30))
                .pollingEvery(Duration.ofSeconds(5))
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class);

        WebElement clickableElement = wait.until(ExpectedConditions.elementToBeClickable(element));
        scrollIntoView(clickableElement);
        try {
            clickableElement.click();
            log.info("Fluent wait completed and element clicked.");
        } catch (Exception e) {
            log.warn("Standard click failed in fluent wait, using JS click.");
            javaScriptClick(clickableElement);
        }
    }

    // Screenshot 
    public void takeScreenshot(String fileName) {
        TakesScreenshot ts = (TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);
        File dest = new File("Screenshot\\" + fileName + ".png");

        try {
            FileUtils.copyFile(src, dest);
            log.info("Screenshot saved: " + dest.getAbsolutePath());
        } catch (IOException e) {
            log.error("Failed to save screenshot: " + e.getMessage());
        }
    }
}