package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.base;

public class Cart extends base{
    WebDriver driver;

    @FindBy(xpath = "//span[text()='Shopping cart']")
    WebElement shoppingcart;

    @FindBy(xpath = "//table[@class='cart']//tr/td[3]/a")
    WebElement verifyproductname;

    @FindBy(xpath = "//span[@class='product-subtotal']")
    WebElement verifytotalprice;
    @FindBy(xpath ="//input[@id='termsofservice']")
    WebElement checkbox;
    @FindBy(xpath ="//button[@id='checkout']")
    WebElement checkout;
    

    public Cart(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void openShoppingCart() {
        shoppingcart.click();
    }

    public String getProductName() {
        return verifyproductname.getText();
    }

    public String getTotalPrice() {
        return verifytotalprice.getText();  
    }

        public void checkbox() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", checkbox);

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(checkbox));

        checkbox.click();
    }

    public void Checkout() {
    	javaScriptClick(checkout);
    }
    

}   