package pages;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;
import utilities.base;

public class checkout extends base {
    WebDriver driver;

    public checkout(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    
    @FindBy(id = "BillingNewAddress_CountryId")
    WebElement country;

    @FindBy(id = "BillingNewAddress_StateProvinceId")
    WebElement state;

    @FindBy(id = "BillingNewAddress_City")
    WebElement city;

    @FindBy(id = "BillingNewAddress_Address1")
    WebElement address1;

    @FindBy(id = "BillingNewAddress_Address2")
    WebElement address2;

    @FindBy(id = "BillingNewAddress_ZipPostalCode")
    WebElement zipCode;

    @FindBy(id = "BillingNewAddress_PhoneNumber")
    WebElement phoneNumber;

    @FindBy(id = "BillingNewAddress_FaxNumber")
    WebElement faxNumber;

    @FindBy(xpath = "//button[contains(@class,'new-address-next-step-button')]")
    WebElement continueBilling;

    @FindBy(xpath = "//button[contains(@class,'shipping-method-next-step-button')]")
    WebElement continueShipping;

    @FindBy(xpath = "//button[contains(@class,'payment-method-next-step-button')]")
    WebElement continuePaymentMethod;

    @FindBy(xpath = "//button[contains(@class,'payment-info-next-step-button')]")
    WebElement continuePaymentInfo;

    @FindBy(xpath = "//button[contains(@class,'confirm-order-next-step-button')]")
    WebElement confirmOrder;

    @FindBy(xpath = "//div[@class=\"section order-completed\"]//h2[@class=\"title\"]")
    WebElement orderSuccessMessage;

    @FindBy(xpath = "//*[@id='checkout-step-payment-method']//input[@type='radio']")
    List<WebElement> paymentMethodRadios;

    public void fillBillingDetails(String ctry, String st, String cty, String addr1, String addr2, String zip, String phone, String fax) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
   
        wait.until(ExpectedConditions.visibilityOf(country));
        new Select(country).selectByVisibleText(ctry);
 
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@id='BillingNewAddress_StateProvinceId']/option[text()='" + st + "']")));
  
        new Select(state).selectByVisibleText(st);

        city.sendKeys(cty);
        address1.sendKeys(addr1);
        address2.sendKeys(addr2);
        zipCode.sendKeys(zip);
        phoneNumber.sendKeys(phone);
        faxNumber.sendKeys(fax);
    }

    public void clickContinueBilling() {
        safeClickElement(continueBilling);
    }

    public void clickContinueShipping() {
        safeClickElement(continueShipping);
    }

    public void clickContinuePaymentMethod() {
        ensurePaymentMethodSelected();
        safeClickElement(continuePaymentMethod);
    }

    public void clickContinuePaymentInfo() {
        safeClickElement(continuePaymentInfo);
    }

    public void clickConfirmOrder() {
        safeClickElement(confirmOrder);
    }

    public String getOrderSuccessMessage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(orderSuccessMessage));
        return orderSuccessMessage.getText();
    }

    
    private void ensurePaymentMethodSelected() {
        if (paymentMethodRadios.isEmpty()) {
            log.warn("No payment method options found.");
            return;
        }
        WebElement firstOption = paymentMethodRadios.get(0);
        if (!firstOption.isSelected()) {
            scrollIntoView(firstOption);
            firstOption.click();
            if (!firstOption.isSelected()) {
                javaScriptClick(firstOption);
            }
        }
    }

    
    private void safeClickElement(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            scrollIntoView(element);
            wait.until(ExpectedConditions.elementToBeClickable(element));
            element.click();
        } catch (Exception e) {
            javaScriptClick(element);
        }
    }
}