package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.base;

public class ProductsPage extends base {
    WebDriver driver;

    @FindBy(xpath = "//a[text()='Computers']")
    WebElement computers;

    @FindBy(xpath = "//a[text()='Notebooks']")
    WebElement notebooks;

    @FindBy(xpath = "//h2[@class='product-title']/a")
    WebElement macbook;

    @FindBy(xpath = "//button[@id='add-to-cart-button-4']")
    WebElement addtocart;

    
    public ProductsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickComputers() {
        computers.click();
    }

    public void clickNotebooks() {
        javaScriptClick(notebooks);
        
    }

    public void selectMacBook() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", macbook);

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(macbook));

        macbook.click();
    }

    public void clickAddToCart() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", addtocart);

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(addtocart));

        addtocart.click();
    }
}