package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class search {
    WebDriver driver;

    public search(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//input[@id='small-searchterms']")
    WebElement searchBox;

    @FindBy(xpath = "//button[@type='submit' and @class='button-1 search-box-button']")
    WebElement searchButton;

    
    @FindBy(xpath = "//div[@class='product-name']/h1")
    WebElement productName;

    
    @FindBy(xpath = "//h2[@class='product-title']/a")
    List<WebElement> resultLinks;

    @FindBy(xpath = "//div[@class='no-result']")
    WebElement noResultMessage;

    
    public void enterProductName(String productNameText) {
        searchBox.clear();
        searchBox.sendKeys(productNameText);
    }

    public void clickSearch() {
        searchButton.click();
    }

   
    public void openProductFromResults(String expectedName) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElements(resultLinks));

        String target = expectedName.trim();
        for (WebElement link : resultLinks) {
            String text = link.getText().trim();
            if (text.equalsIgnoreCase(target)) {
                link.click();
                return;
            }
        }
        throw new RuntimeException("Product not found in search results: " + expectedName);
    }

  
    public String get_product_name() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(productName));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", productName);
        return productName.getText().trim();
    }

    public String getNoResultMessage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOf(noResultMessage));
        return noResultMessage.getText().trim();
    }
}
