package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.base;

public class Registration extends base{
    WebDriver driver;
    @FindBy(xpath="//a[@class='ico-register']")
    WebElement registerbutton;
    
    @FindBy(xpath="//input[@type=\"radio\"]")
    WebElement gender;

    @FindBy(id = "FirstName")
    WebElement firstName;

    @FindBy(id = "LastName")
    WebElement lastName;

    @FindBy(id = "Email")
    WebElement email;

    @FindBy(id = "Password")
    WebElement password;

    @FindBy(id = "ConfirmPassword")
    WebElement confirmPassword;

    @FindBy(id = "register-button")
    WebElement register;
    
    public Registration(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public void register_button() {
    	registerbutton.click();
    }
    public void select_gender(String genderValue) {
        if (genderValue.equalsIgnoreCase("Male")) {
            driver.findElement(By.id("gender-male")).click();
        } else if (genderValue.equalsIgnoreCase("Female")) {
            driver.findElement(By.id("gender-female")).click();
        } else {
            throw new IllegalArgumentException("Invalid gender: " + genderValue);
        }
    }
    public void enterFirstName(String firstname) {
        firstName.sendKeys(firstname);
    }

    public void enterLastName(String lastname) {
        lastName.sendKeys(lastname);
    }

    public void enterEmail(String emailAddress) {
        email.sendKeys(emailAddress);
    }

    public void enterPassword(String pwd) {
        password.sendKeys(pwd);
    }

    public void enterConfirmedPassword(String confirmPwd) {
        confirmPassword.sendKeys(confirmPwd);
    }

    public void clickRegister() {
    	log.info ("clicked register button");
        register.click();
    }
}