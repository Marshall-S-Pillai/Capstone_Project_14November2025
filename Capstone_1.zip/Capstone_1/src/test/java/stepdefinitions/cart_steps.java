package stepdefinitions;

import io.cucumber.java.en.*;
import org.testng.Assert;
import pages.Cart;
import pages.LoginPage;
import utilities.base;

public class cart_steps extends base {
    Cart cartPage;
    LoginPage loginPage;

    @And("User opens Shopping Cart")
    public void user_opens_shopping_cart() {
        log.info("Executing method: user_opens_shopping_cart");
        if (cartPage == null) {
            cartPage = new Cart(driver); 
        }
        cartPage.openShoppingCart();
        System.out.println("Opened Shopping Cart");
    }

    @Then("Verify product name is {string}")
    public void verify_product_name_is(String expectedName) {
        log.info("Executing method: verify_product_name_is");
        String actualName = cartPage.getProductName();
        Assert.assertEquals(actualName, expectedName, "Product name mismatch!");
        System.out.println("Verified product name: " + actualName);
    }

    @Then("Verify total price contains {string}")
    public void verify_total_price_contains(String expectedPrice) {
        log.info("Executing method: verify_total_price_contains");
        String actualPrice = cartPage.getTotalPrice();
        Assert.assertTrue(actualPrice.contains(expectedPrice), "Total price mismatch!");
        System.out.println("Verified total price: " + actualPrice);
        takeScreenshot("Products verfied in cart");
    }
}