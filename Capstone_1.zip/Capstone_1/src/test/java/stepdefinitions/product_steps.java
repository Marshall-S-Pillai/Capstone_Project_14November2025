package stepdefinitions;

import io.cucumber.java.en.*;
import org.testng.Assert;
import pages.Cart;
import pages.LoginPage;
import pages.ProductsPage;
import utilities.base;

public class product_steps extends base {

    LoginPage loginPage;
    ProductsPage productPage;

    @When("User clicks on Computers")
    public void user_clicks_on_computers() {
        log.info("Executing method: user_clicks_on_computers");
        if (productPage == null) {
            productPage = new ProductsPage(driver);
        }
        productPage.clickComputers();
        System.out.println("Clicked on Computers");
    }

    @And("User clicks on Notebooks")
    public void user_clicks_on_notebooks() {
        log.info("Executing method: user_clicks_on_notebooks");
        productPage.clickNotebooks();
        System.out.println("Clicked on Notebooks");
    }

    @And("User selects {string}")
    public void user_selects_product(String product) {
        log.info("Executing method: user_selects_product");
        productPage.selectMacBook();
        System.out.println("Selected product: " + product);
    }

    @And("User clicks Add to Cart")
    public void user_clicks_add_to_cart() {
        log.info("Executing method: user_clicks_add_to_cart");
        productPage.clickAddToCart();
        System.out.println("Clicked Add to Cart");
    }
}