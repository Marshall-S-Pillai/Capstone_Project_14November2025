package stepdefinitions;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.Registration;
import utilities.base;
import io.cucumber.java.en.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class registration_steps extends base {
    private static final Logger log = LoggerFactory.getLogger(registration_steps.class);
    Registration reg;
    WebDriverWait wait;

    @And("User is on the registration page")
    public void user_is_on_the_registration_page() {
        log.info("Navigating to registration page");
        reg = new Registration(driver); 
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='ico-register']")));
        reg.register_button();
        System.out.println("Navigated to registration page");
    }

    @When("User Selects gender {string}")
    public void user_selects_gender(String gender) {
        log.info("Selecting gender: {}", gender);
        reg.select_gender(gender);
        System.out.println("Selected gender: " + gender);
    }

    @And("User enters registration first name {string}")
    public void user_enters_registration_first_name(String firstname) {
        log.info("Entering first name: {}", firstname);
        reg.enterFirstName(firstname);
        System.out.println("Entered first name: " + firstname);
    }

    @And("User enters registration last name {string}")
    public void user_enters_registration_last_name(String lastname) {
        log.info("Entering last name: {}", lastname);
        reg.enterLastName(lastname);
        System.out.println("Entered last name: " + lastname);
    }

    @And("User enters registration email {string}")
    public void user_enters_registration_email(String email) {
        log.info("Entering email: {}", email);
        reg.enterEmail(email);
        System.out.println("Entered email: " + email);
    }

    @And("User enters registration password {string}")
    public void user_enters_registration_password(String password) {
        log.info("Entering password");
        reg.enterPassword(password);
        System.out.println("Entered password");
    }

    @And("User confirms password {string}")
    public void user_confirms_password(String confirmPassword) {
        log.info("Confirming password");
        reg.enterConfirmedPassword(confirmPassword);
        System.out.println("Confirmed password");
    }

    @And("User clicks on the Register button")
    public void user_clicks_on_the_register_button() {
        log.info("Clicking Register button");
        wait.until(ExpectedConditions.elementToBeClickable(By.id("register-button")));
        reg.clickRegister();
        System.out.println("Clicked Register button");
    }

    @Then("User should see a registration success message {string}")
    public void user_should_see_a_registration_success_message(String expectedMessage) {
        log.info("Validating registration success message: {}", expectedMessage);
        String actualMessage = driver.findElement(By.className("result")).getText();
        if (actualMessage.contains(expectedMessage)) {
            log.info("Registration successful: {}", actualMessage);
            takeScreenshot("Registration successful");
            System.out.println("Registration successful: " + actualMessage);
        } else {
            log.info("Registration failed. Expected: {}, but got: {}", expectedMessage, actualMessage);
            takeScreenshot("Registration failed");
            System.out.println("Registration failed. Expected: " + expectedMessage + ", but got: " + actualMessage);
        }
        closeBrowser();
    }
}