package stepdefinitions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.apache.log4j.Logger;
import pages.LoginPage;
import utilities.base;
import io.cucumber.java.en.*;

public class login_steps extends base {
    LoginPage lp;
    WebDriverWait wait;
    
    @Given("the user opens the {string} browser")
    public void openBrowser(String browser) {
        log.info("Executing method: openBrowser");
        if (browser.equalsIgnoreCase("chrome")) {
            launch_chrome();
        } else if (browser.equalsIgnoreCase("edge")) {
            launchEdge();
        } else {
            throw new IllegalArgumentException("Unsupported Browser: " + browser);
        }
        log.info("Browser launched: " + browser);
    }

    @When("User is on the login page")
    public void openLoginPage() {
        log.info("Executing method: openLoginPage");
        lp = new LoginPage(driver);
        lp.click_bt(); 
        log.info("Opened Login page");
    }

    @When("User enters username {string}")
    public void enterUsername(String username) {
        log.info("Executing method: enterUsername");
        lp.enter_usern(username);
        log.info("Entered username: " + username);
    }

    @And("User enters password {string}")
    public void enterPassword(String password) {
        log.info("Executing method: enterPassword");
        lp.enter_passw(password);
        log.info("Entered password");
    }

    @And("User clicks on the Sign in button")
    public void user_clicks_on_the_sign_in_button() {
        log.info("Executing method: user_clicks_on_the_sign_in_button");
        String loginBtnXpath = "//button[contains(@class,'button-1 login-button')]";
        explicitWait(loginBtnXpath, "clickable");
        driver.findElement(By.xpath(loginBtnXpath)).click();
        System.out.println("Clicked Sign in button");
    }
    
    @Then("User should be redirected to the dashboard")
    public void user_should_be_redirected_to_the_dashboard() {
        log.info("Executing method: user_should_be_redirected_to_the_dashboard");
        System.out.println("Login successful: redirected to dashboard");
        takeScreenshot("Login successful");
        fluentWait(lp.logoutclick);  
        driver.quit();
    }

    @Then("An error message {string} should be displayed")
    public void an_error_message_should_be_displayed(String expectedMessage) {
        log.info("Executing method: an_error_message_should_be_displayed");
        String actualMessage = lp.invalid_login();
        Assert.assertTrue(actualMessage.contains(expectedMessage),
            "Error message mismatch. Expected to contain: " + expectedMessage + " but found: " + actualMessage);
        System.out.println("Login failed: " + actualMessage);
        takeScreenshot("Login failed");
        driver.quit();
    }
}