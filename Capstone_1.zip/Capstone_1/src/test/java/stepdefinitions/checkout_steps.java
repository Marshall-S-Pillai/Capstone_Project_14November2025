package stepdefinitions;

import java.time.Duration;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.cucumber.java.en.*;
import pages.checkout;
import pages.LoginPage;
import pages.Cart;
import utilities.base;
import org.testng.Assert;

public class checkout_steps extends base {

    checkout checkoutPage;
    LoginPage loginPage;
    Cart cartPage;
    WebDriverWait wait;

    @And("click the terms of service check box")
    public void click_check_box() {
        log.info("Executing method: click_check_box()");
        if (cartPage == null) {
            cartPage = new Cart(driver); 
        }
        cartPage.checkbox();
        System.out.println("Clicked check box");
        log.info("Clicked check box");
    }

    @And("click the checkout button")
    public void click_checkout_button() {
        log.info("Executing method: click_checkout_button()");
        cartPage.Checkout();
        System.out.println("Clicked checkout button");
        log.info("Clicked checkout button");
    }

    @Given("User is on the checkout page")
    public void user_is_on_checkout_page() {
        log.info("Executing method: user_is_on_checkout_page()");
        System.out.println("Navigated to Checkout page");
        log.info("Navigated to Checkout page");
    }

    @When("User enters billing details with country {string}, state {string}, city {string}, address1 {string}, address2 {string}, zip {string}, phone {string}, fax {string}")
    public void user_enters_billing_details(String country, String state, String city, String address1, String address2, String zip, String phone, String fax) {
        log.info("Executing method: user_enters_billing_details()");
        checkoutPage = new checkout(driver);
        checkoutPage.fillBillingDetails(country, state, city, address1, address2, zip, phone, fax);
        System.out.println("Entered billing details");
        log.info("Entered billing details");
    }

    @And("User clicks continue on billing section")
    public void user_clicks_continue_on_billing_section() {
        log.info("Executing method: user_clicks_continue_on_billing_section()");
        checkoutPage.clickContinueBilling();
        System.out.println("Clicked continue on billing section");
        log.info("Clicked continue on billing section");
    }

    @And("User clicks continue on shipping section")
    public void user_clicks_continue_on_shipping_section() {
        log.info("Executing method: user_clicks_continue_on_shipping_section()");
        checkoutPage.clickContinueShipping();
        System.out.println("Clicked continue on shipping section");
        log.info("Clicked continue on shipping section");
    }

    @And("User clicks continue on payment method section")
    public void user_clicks_continue_on_payment_method_section() {
        log.info("Executing method: user_clicks_continue_on_payment_method_section()");
        checkoutPage.clickContinuePaymentMethod();
        System.out.println("Clicked continue on payment method section");
        log.info("Clicked continue on payment method section");
    }

    @And("User clicks continue on payment info section")
    public void user_clicks_continue_on_payment_info_section() {
        log.info("Executing method: user_clicks_continue_on_payment_info_section()");
        checkoutPage.clickContinuePaymentInfo();
        System.out.println("Clicked continue on payment info section");
        log.info("Clicked continue on payment info section");
    }

    @And("User confirms the order")
    public void user_confirms_the_order() {
        log.info("Executing method: user_confirms_the_order()");
        checkoutPage.clickConfirmOrder();
        System.out.println("Confirmed the order");
        log.info("Confirmed the order");
    }

    @Then("User should see order success message {string}")
    public void user_should_see_order_success_message(String expectedMessage) {
        log.info("Executing method: user_should_see_order_success_message()");
        String actualMessage = checkoutPage.getOrderSuccessMessage();
        Assert.assertEquals(actualMessage, expectedMessage, "Order success message mismatch!");
        System.out.println("Verified success message: " + actualMessage);
        log.info("Verified success message: " + actualMessage);
        takeScreenshot("Order Successful");
        closeBrowser();
    }
}