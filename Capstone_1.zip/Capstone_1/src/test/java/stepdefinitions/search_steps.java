package stepdefinitions;

import java.time.Duration;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import pages.search;
import utilities.base;
import io.cucumber.java.en.*;

public class search_steps extends base {
    search searchPage;
    WebDriverWait wait;

    @Given("User is on the home page")
    public void user_is_on_the_home_page() {
        log.info("Executing method: user_is_on_the_home_page");
        launch_chrome();
        searchPage = new search(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        System.out.println("Navigated to home page");
    }

    @When("User searches for product {string}")
    public void user_searches_for_product(String productName) {
        log.info("Executing method: user_searches_for_product");
        searchPage.enterProductName(productName);
        searchPage.clickSearch();
        System.out.println("Searched for product: " + productName);
    }

    @Then("User should see the product name {string}")
    public void user_should_see_the_product_name(String expectedProductName) {
        log.info("Executing method: user_should_see_the_product_name");
        searchPage.openProductFromResults(expectedProductName);

        String actualProductName = searchPage.get_product_name();
        Assert.assertEquals(actualProductName, expectedProductName, "Product name does not match!");
        System.out.println("Product found: " + actualProductName);
        takeScreenshot("Search successful");
        driver.quit();
    }

    @Then("User should see a message {string}")
    public void user_should_see_a_message(String expectedMessage) {
        log.info("Executing method: user_should_see_a_message");
        String actualMessage = searchPage.getNoResultMessage();
        Assert.assertEquals(actualMessage, expectedMessage, "No-result message does not match!");
        System.out.println("No-result message displayed: " + actualMessage);
        takeScreenshot("Search unsuccessful");
        driver.quit();
    }
}